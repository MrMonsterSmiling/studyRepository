const http = require('http');
const fs = require('fs');
const utils = require('./module/utils.js');
const path = require('path');
const url = require('url');
http.createServer(async function (request, response) {
    console.log(url.parse(request.url));
    let pathname = url.parse(request.url).pathname;//获取静态资源路径，以及去掉参数(?后面的)
    pathname = pathname == '/'?"/index.html" : pathname;//默认访问index.html
    let extname = path.extname(pathname);//获取请求资源的后缀名
    let mime = await utils.utils.getFileMime(extname);//设置返回头，还不完整
    console.log("响应类型",mime);
    if(pathname!='/favicon.ico'){
        fs.readFile("./static"+pathname,(error,data)=>{
            if(error){
                response.writeHead(404,{'content-type':'text/html;charset="utf-8"'});
                response.end("404")
                console.log(error);
                return;
            }
            response.writeHead(200, {'Content-Type':''+mime+';charset="utf-8"'});
            response.end(data);
        })
    }
 
}).listen(8081);

console.log('Server running at http://127.0.0.1:8081/');